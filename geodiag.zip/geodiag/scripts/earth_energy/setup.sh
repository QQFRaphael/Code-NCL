#!/bin/bash

export GEODIAG_CERES_EBAF=$(dirname $BASH_ARGV)/ceres-ebaf
export GEODIAG_CERES_EBAF_DATA=$GEODIAG_ROOT/data/ceres-ebaf/CERES_EBAF_TOA_Terra_Edition1A_200003-200510.nc
